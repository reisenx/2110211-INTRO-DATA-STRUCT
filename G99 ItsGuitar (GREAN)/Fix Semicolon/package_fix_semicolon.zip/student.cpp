#include<iostream>
int main(){
	std::cout<<"I love data structure!"
	return 0;
}
