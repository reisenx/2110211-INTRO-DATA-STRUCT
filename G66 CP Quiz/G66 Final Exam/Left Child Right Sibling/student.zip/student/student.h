// You may include library here

int depth(node *n)
{
  // Write Code Here
}