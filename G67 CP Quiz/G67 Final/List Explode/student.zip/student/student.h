
#ifndef __STUDENT_H_
#define __STUDENT_H_

// You can include library here
#include "list.h"
#include "vector.h"

template <typename T>
CP::vector<CP::list<T>> CP::list<T>::explode(){
    /*

        “Great results, can be achieved with small forces.”
        ― Sun Tzu, The Art of War 

    */
    
}

#endif
