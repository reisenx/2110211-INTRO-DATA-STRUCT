#ifndef __STUDENT_H_
#define __STUDENT_H_

// You can include library here
#include <vector>

using namespace std;

class hotel {
  	// you can declare variables or write new function

public:
    hotel(vector <int> rooms) {
    	// your code here
    }

    void next_day() {
        // your code here
    }

    vector <pair <int, int>> check_in(int group, int num) {
        // your code here
        return {};
    }

    int check_out(int group, int floor) {
        // your code here
        return 0;
    }
};

#endif
