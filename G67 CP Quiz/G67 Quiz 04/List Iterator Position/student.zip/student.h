#ifndef __STUDENT_H_
#define __STUDENT_H_

// You can include library here
#include "list.h"

template <typename T>
int CP::list<T>::data_iterator(CP::list<T>::iterator it) {
  // Write code here
  return -2;
}

#endif
