void splitList(list<T>& list1, list<T>& list2) {
    // Add your code here

}
