void replace(const T& x, list<T>& y) {
  //write your code here

}
