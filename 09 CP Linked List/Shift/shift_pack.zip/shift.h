void shift(int k) {
	// TODO: Add your code here

}
